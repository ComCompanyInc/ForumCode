package com.example.forumcode;

import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Arrays;

public class TextContentActivity extends AppCompatActivity {
    private TextView textTitle;
    private TextView textContent;
    private int category = 0;
    private int position = 0;
    private String selectedThemeListViewName = null;

    private String arraySubTheme;
    //design
    private Typeface fontFace1;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.text_content);

        textTitle = findViewById(R.id.Title);
        textContent = findViewById(R.id.mainText);



        fontFace1 = Typeface.createFromAsset(this.getAssets(), "fonts/Pacifico-Regular.ttf");
        textContent.setTypeface(fontFace1);

        reciveIntent();
    }
    private void reciveIntent() // метод, получающий данные о выбранной категории и теме
    {
        //получаем данные о категории и выбранной теме (передаем данные через intent)
        Intent intent = getIntent();

        if(intent != null)
        {
            category = intent.getIntExtra("category", 0);
            position = intent.getIntExtra("position", 0);
            selectedThemeListViewName = intent.getStringExtra("name");
        }

            //switch (category)
            //{
            //case 0:

            Client client = new Client("OPNF_" + selectedThemeListViewName + "_" + category);
            Thread thread = new Thread(client);
            thread.start();

            synchronized (thread) {
                try {
                    thread.join(); // Ожидаем завершения работы потока

                    //System.out.println("qwe+"+client.response);

                    arraySubTheme = client.response;
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }

            textTitle.setText(selectedThemeListViewName);
        //textContent.setText(arraySubTheme);

        String[] messages = arraySubTheme.split("ANSV");
        String res = "";
        int len = messages.length;
        int i = 0;
        while (i < len)
        {
            res = res + "\n" + messages[i] + "\n";
            i++;
        }
        textContent.setText(res);
            //break;
            //case 1:
            //break;
            //case 2:
            //break;
            //case 3:
            //break;
            //case 4:
            //break;
            //case 5:
            //break;
            //}
    }
    public void OnButtonAnswer(View view)
    {
        Intent intentAnsw = new Intent(TextContentActivity.this, TextAnswerActivity.class);
        intentAnsw.putExtra("nameOfGlobalTheme", category);
        intentAnsw.putExtra("nameOfTheme", selectedThemeListViewName);
        startActivity(intentAnsw);

        finish();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Toast.makeText(this, "CLOSED!", Toast.LENGTH_SHORT).show();
        finish();
    }
}
