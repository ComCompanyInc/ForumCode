package com.example.forumcode;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;

import androidx.annotation.Nullable;

public class LogoActivity extends Activity {
    private Animation logoAnim;

    private ImageView logo;
    private Button button;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.logo_activity);

        logo = findViewById(R.id.idLogo);
        button = findViewById(R.id.idButtonConnect);

        logoAnim = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.alpha_in);
        logo.startAnimation(logoAnim);


    }

    public void OnStartClick(View view)
    {
        logoAnim = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.alpha_out);
        button.startAnimation(logoAnim);

        Intent intentStart = new Intent(LogoActivity.this, MainActivity.class);
        startActivity(intentStart);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        finish();
    }
}
