package com.example.forumcode;

import android.os.AsyncTask;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;

public class Client implements Runnable{
    //CRTE_theme33_Hello world!
    //GETF_h
    private String serverIP = "194.87.74.77"; //"192.168.1.103"
    private int serverPort = 5000;
    private Socket socket;
    private PrintWriter out;
    public String response;

    public Client(String response) {
        this.response = (response).replaceAll("[\"\\n]", "");
    }

    public String connectToServer() {
        try {
            socket = new Socket(serverIP, serverPort);
            out = new PrintWriter(socket.getOutputStream(), true);
            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            //BufferedReader userInput = new BufferedReader(new InputStreamReader(System.in));

            //String userString;
            /*while ((userString = userInput.readLine();/*) != null) {*/
            out.println(response);
            String answer = in.readLine();
            System.out.println("Server answer: " + answer);
            return answer;
            //}
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                out.close();
                socket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return "0";
    }

    @Override
    public void run() {
        response = connectToServer();
        //Log.d("MyThread", "Data in MyThread: " + response);
    }
}
