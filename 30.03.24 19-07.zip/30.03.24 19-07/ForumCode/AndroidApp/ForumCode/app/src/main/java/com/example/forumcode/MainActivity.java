package com.example.forumcode;

import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.view.MenuItem;
import android.view.View;
import android.view.Menu;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.navigation.NavigationView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;

import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.app.AppCompatActivity;

import com.example.forumcode.databinding.ActivityMainBinding;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;

public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener{
    private DrawerLayout drawer;

    private ListView list;
    private String arrayThemes[];
    private ArrayAdapter<String> adapter;
    Toolbar toolbar;
    private int category_index;

    private ActivityMainBinding binding;

    private String metaFilePath = "metaFiles";
    String userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        //Thread thread = new Thread(new Client());
        //thread.start();

        toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle(R.string.home);

        list = findViewById(R.id.listView);


        //writeUserId();
        getUserId();


        Client client = new Client("GETF_0");
        Thread thread = new Thread(client);
        thread.start();

        synchronized (thread) {
            try {
                thread.join(); // Ожидаем завершения работы потока

                //System.out.println("qwe+"+client.response);

                arrayThemes = client.response.split("_");
                adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, new ArrayList<String>(Arrays.asList(arrayThemes)));
                list.setAdapter(adapter);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        //Client client = new Client();
        //if(client.connectToServer("GETF_h") != null) {
            //arrayThemes = client.connectToServer("GETF_h").split("_");
            //adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, arrayThemes);
            //list.setAdapter(adapter);
        //}else
        //{
            //System.out.println("Error!");
        //}

        setSupportActionBar(binding.appBarMain.toolbar);

        drawer = binding.drawerLayout;
        //NavigationView navigationView = findViewById(R.id.nav_view);
        NavigationView navigationView = binding.navView;

        Toolbar toolbar=findViewById(R.id.toolbar);

        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();
        navigationView.setNavigationItemSelectedListener(this); // присваеваем слушатель к имплементу класса
        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.

        list.setOnItemClickListener(new AdapterView.OnItemClickListener() { // обработчик нажатия на ITEM в list view
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(MainActivity.this, TextContentActivity.class); // открытие новой страницы
                intent.putExtra("category", category_index);// передача переменной в класс другого окна по ключевому слову (выбранная в шторке категория)
                intent.putExtra("position", position);// передача переменной в класс другого окна по ключевому слову (выбранная тема из категории на list view)
                intent.putExtra("name", ((TextView) view).getText().toString());// передача переменной в класс другого окна по ключевому слову (выбранная тема из категории на list view)
                startActivity(intent);
            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {// слушатель нажатий на выбранную категорию выдвижной катушки слева
        int id = item.getItemId(); //берем у нажатой категории id

        if(id == R.id.id_globalTitle1)
        {
            //Toast.makeText(this, "Nav home is pressed !", Toast.LENGTH_SHORT).show();
            toolbar.setTitle(R.string.home);

            Client client = new Client("GETF_0");
            Thread thread = new Thread(client);
            thread.start();

            synchronized (thread) {
                try {
                    thread.join(); // Ожидаем завершения работы потока

                    //System.out.println("qwe+"+client.response);

                    arrayThemes = client.response.split("_");
                    adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, new ArrayList<String>(Arrays.asList(arrayThemes)));
                    list.setAdapter(adapter);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            adapter.clear();
            adapter.addAll(arrayThemes);
            adapter.notifyDataSetChanged();

            category_index = 0;
        }
        else if(id == R.id.id_globalTitle2)
        {
            //Toast.makeText(this, "Nav gallery is pressed !", Toast.LENGTH_SHORT).show();
            toolbar.setTitle(R.string.home2);

            Client client = new Client("GETF_1");
            Thread thread = new Thread(client);
            thread.start();

            synchronized (thread) {
                try {
                    thread.join(); // Ожидаем завершения работы потока

                    //System.out.println("qwe+"+client.response);

                    arrayThemes = client.response.split("_");
                    adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, new ArrayList<String>(Arrays.asList(arrayThemes)));
                    list.setAdapter(adapter);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            adapter.clear();
            adapter.addAll(arrayThemes);
            adapter.notifyDataSetChanged();

            category_index = 1;
        }
        else if(id == R.id.id_globalTitle3)
        {
            //Toast.makeText(this, "Nav gallery is pressed !", Toast.LENGTH_SHORT).show();
            toolbar.setTitle(R.string.home3);

            Client client = new Client("GETF_2");
            Thread thread = new Thread(client);
            thread.start();

            synchronized (thread) {
                try {
                    thread.join(); // Ожидаем завершения работы потока

                    //System.out.println("qwe+"+client.response);

                    arrayThemes = client.response.split("_");
                    adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, new ArrayList<String>(Arrays.asList(arrayThemes)));
                    list.setAdapter(adapter);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            adapter.clear();
            adapter.addAll(arrayThemes);
            adapter.notifyDataSetChanged();

            category_index = 2;
        }
        else if(id == R.id.id_globalTitle4)
        {
            //Toast.makeText(this, "Nav gallery is pressed !", Toast.LENGTH_SHORT).show();
            toolbar.setTitle(R.string.home4);

            Client client = new Client("GETF_3");
            Thread thread = new Thread(client);
            thread.start();

            synchronized (thread) {
                try {
                    thread.join(); // Ожидаем завершения работы потока

                    //System.out.println("qwe+"+client.response);

                    arrayThemes = client.response.split("_");
                    adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, new ArrayList<String>(Arrays.asList(arrayThemes)));
                    list.setAdapter(adapter);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            adapter.clear();
            adapter.addAll(arrayThemes);
            adapter.notifyDataSetChanged();

            category_index = 3;
        }
        else if(id == R.id.id_globalTitle5)
        {
            //Toast.makeText(this, "Nav gallery is pressed !", Toast.LENGTH_SHORT).show();
            toolbar.setTitle(R.string.home5);

            Client client = new Client("GETF_4");
            Thread thread = new Thread(client);
            thread.start();

            synchronized (thread) {
                try {
                    thread.join(); // Ожидаем завершения работы потока

                    //System.out.println("qwe+"+client.response);

                    arrayThemes = client.response.split("_");
                    adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, new ArrayList<String>(Arrays.asList(arrayThemes)));
                    list.setAdapter(adapter);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            adapter.clear();
            adapter.addAll(arrayThemes);
            adapter.notifyDataSetChanged();

            category_index = 4;
        }
        else if(id == R.id.id_globalTitle6)
        {
            //Toast.makeText(this, "Nav gallery is pressed !", Toast.LENGTH_SHORT).show();
            toolbar.setTitle(R.string.home6);

            Client client = new Client("GETF_5");
            Thread thread = new Thread(client);
            thread.start();

            synchronized (thread) {
                try {
                    thread.join(); // Ожидаем завершения работы потока

                    //System.out.println("qwe+"+client.response);

                    arrayThemes = client.response.split("_");
                    adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, new ArrayList<String>(Arrays.asList(arrayThemes)));
                    list.setAdapter(adapter);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            adapter.clear();
            adapter.addAll(arrayThemes);
            adapter.notifyDataSetChanged();

            category_index = 5;
        }
        else if(id == R.id.id_globalCreator)
        {
            Intent nextIntent = new Intent(MainActivity.this, TextCreateThemeActivity.class); // открытие новой страницы
            startActivity(nextIntent);
        }
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Toast.makeText(this, "CLOSED!", Toast.LENGTH_SHORT).show();
        finish();
    }

    public void writeUserId()
    {
        try {
            FileOutputStream fileOutputStream = openFileOutput("user_data.txt", MODE_PRIVATE);

            Client client = new Client("UNAME");
            Thread thread = new Thread(client);
            thread.start();

            synchronized (thread) {
                try {
                    thread.join(); // Ожидаем завершения работы потока

                    //System.out.println("qwe+"+client.response);

                    userId = client.response;
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }

            fileOutputStream.write(userId.getBytes());
            fileOutputStream.close();

        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }


        //getUserId();
    }

    public void getUserId()
    {
        try {
            FileInputStream fileInputStream = openFileInput("user_data.txt");
            InputStreamReader inputStreamReader = new InputStreamReader(fileInputStream);
            BufferedReader bufferedReader = new BufferedReader(inputStreamReader);

            String line = "", result = "";
            while((line = bufferedReader.readLine()) != null)
            {
                result += line;
            }

            Toast.makeText(this,result, Toast.LENGTH_SHORT).show();
        } catch (IOException e) {
            e.printStackTrace();

            writeUserId();
        }
    }
}