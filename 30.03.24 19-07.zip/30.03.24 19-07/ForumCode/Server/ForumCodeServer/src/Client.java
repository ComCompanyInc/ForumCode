import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

public class Client implements Runnable{
    //CRTE_theme33_Hello world!
    //GETF_h
    private String serverIP = "127.0.0.1";
    private int serverPort = 5000;
    private Socket socket;
    private PrintWriter out;

    public void connectToServer(String response) {
        try {
            socket = new Socket(serverIP, serverPort);
            out = new PrintWriter(socket.getOutputStream(), true);
            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            //BufferedReader userInput = new BufferedReader(new InputStreamReader(System.in));

            //String userString;
            /*while ((userString = userInput.readLine();/*) != null) {*/
                out.println(response);
                String answer = in.readLine();
                System.out.println("Server answer: " + answer);
            //}
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                out.close();
                socket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public static void main(String[] args) {
        //Client client = new Client("127.0.0.1", 5000); // Set server IP and port
        //client.connectToServer();
        Thread thread = new Thread(new Client());
        thread.start();
    }

    @Override
    public void run() {
        Client client = new Client(); // Set server IP and port
        client.connectToServer(("UNAME").replaceAll("[\"\\n]", "") + "_0");//GETF_0 || ANSVF_theme33.txt_Hi there, how are you?_0 || UNAME || CRTE_Hello!_Some Text_0
    }
}
