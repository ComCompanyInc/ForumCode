package com.example.forumcode;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;

public class TextCreateThemeActivity extends AppCompatActivity {
    private Spinner spinGlobal;
    private EditText editTheme;
    private EditText editDescription;
    private String[] globalThemes = {"Обсуждения и новости", "Технологии и алгоритмы", "Применение в областях", "Этические вопросы", "Обучение и карьера в AI", "Проэкты и задания"};
    private int indexTheme = 0;
    private ArrayAdapter<String> adapter;
    String res;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.create_theme);

        spinGlobal = findViewById(R.id.spinner);
        editTheme = findViewById(R.id.theme_id);
        editDescription = findViewById(R.id.description_id);

        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, new ArrayList<String>(Arrays.asList(globalThemes)));
        spinGlobal.setAdapter(adapter);
        adapter.notifyDataSetChanged();
    }

    public int init(String spGl)
    {
        if(spGl == "Обсуждения и новости")
        {
            indexTheme = 0;
        }
        else if(spGl == "Технологии и алгоритмы")
        {
            indexTheme = 1;
        }
        else if(spGl == "Применение в областях")
        {
            indexTheme = 2;
        }
        else if(spGl == "Этические вопросы")
        {
            indexTheme = 3;
        }
        else if(spGl == "Обучение и карьера в AI")
        {
            indexTheme = 4;
        }
        else if(spGl == "Проэкты и задания")
        {
            indexTheme = 5;
        }
        return indexTheme;
    }
    public void onClickStart(View view)//слушатель нажатия кнопки
    {
        Client client = new Client("CRTE_" + editTheme.getText() + "_" + editDescription.getText()+" ("+getUserId()+")" +"_"+init(spinGlobal.getSelectedItem().toString()));
        Thread thread = new Thread(client);
        thread.start();

        synchronized (thread) {
            try {
                thread.join(); // Ожидаем завершения работы потока

                //System.out.println("qwe+"+client.response);

                res = client.response;
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        //textTitle.setText(selectedThemeListViewName);
        //textContent.setText(arraySubTheme);

        Toast.makeText(this, res, Toast.LENGTH_SHORT).show();

        finish();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Toast.makeText(this, "CLOSED!", Toast.LENGTH_SHORT).show();
        finish();
    }

    public String getUserId()
    {
        String line = "", result = "";
        try {
            FileInputStream fileInputStream = openFileInput("user_data.txt");
            InputStreamReader inputStreamReader = new InputStreamReader(fileInputStream);
            BufferedReader bufferedReader = new BufferedReader(inputStreamReader);

            while((line = bufferedReader.readLine()) != null)
            {
                result += line;
            }

            Toast.makeText(this,result, Toast.LENGTH_SHORT).show();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return result;
    }
}
