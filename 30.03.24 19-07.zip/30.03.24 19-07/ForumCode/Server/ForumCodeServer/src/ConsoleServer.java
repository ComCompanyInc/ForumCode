import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Random;
import java.util.Scanner;

public class ConsoleServer extends Thread{
    public String ipAddress;
    public String port;

    public String serverThemePath /*= "ServerThemes\\"*/;
    ZonedDateTime currentTime = ZonedDateTime.now(ZoneId.of("Europe/Moscow"));
    public void Start(String pathArg)
    {
        ipAddress = "lockalhost";
        port = "5000";

        //System.out.println("Current time in Europe/Paris: " + currentTime.toLocalTime());

        System.out.println("<<- Server started width path ->> "+pathArg);
        serverThemePath = pathArg;

        //System.out.println("Enter path data ->>");
        //Scanner scan = new Scanner(System.in);

        //serverThemePath = scan.nextLine();

        try {
            while(true) {
                CreateConnection();
            }
        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }
    }

    PrintWriter writer;
    public void CreateConnection() throws IOException
    {
        try(
                ServerSocket serverSocket = new ServerSocket(Integer.parseInt(port));
                Socket socket = serverSocket.accept();
                Scanner scanner = new Scanner(socket.getInputStream())
        )
        {
            writer = new PrintWriter(socket.getOutputStream(), true);

            if (scanner.hasNextLine()) {
                String str = scanner.nextLine(); //!!
                //writer.println("Client message: "+str);

                System.out.println(str);

                writer.println(requestProcessing(str));
            }
        }
        catch (IOException ex)
        {
            System.out.println("Error: "+ex);
        }
    }

    public String requestProcessing(String request) throws IOException {
        try {
            String[] words = request.split("_");

            for (int i = 0; i < words.length; i++) {
                System.out.println("words[" + i + "] = " + words[i]);
            }

            if (words[0].equals("CRTE")) {
                if (createServerTheme(words[1], words[2], words[3]) == 200) {
                    //writer.println("200");
                    return "200";
                }
            } else if (words[0].equals("GETF")) {
                return getServerTheme(words[1]);
            } else if (words[0].equals("OPNF")) {
                return openServerTheme(words[1], words[2]);
            } else if (words[0].equals("ANSVF")) {
                if (ansverServerTheme(words[1], words[2], words[3]) == 200) {
                    return "200";
                }
            } else if (words[0].equals("UNAME")) {
                return getUserName();
            }
            return "-100";
        }
        catch (Exception exception)
        {
            return "Error input data: "+ exception;
        }
    }

    public void createGlobalThemeDir(String nameOfGlobalTheme)
    {
        File dirGlobal = new File(serverThemePath + nameOfGlobalTheme);
        if(!dirGlobal.exists())
        {
            dirGlobal.mkdir();
        }
    }
    public int createServerTheme(String nameOfTheme, String textTheme, String nameOfGlobalTheme) throws IOException // создание темы
    {
        createGlobalThemeDir(nameOfGlobalTheme);

        System.out.println("_____________________ " + nameOfTheme+"_____ "+textTheme);
        File file = new File(serverThemePath + nameOfGlobalTheme+"/" + nameOfTheme+".txt");
        file.createNewFile();

        FileWriter fileWriter = new FileWriter(file);
        fileWriter.write(" "+textTheme+" ["+currentTime.toLocalTime().toString()+"]");

        fileWriter.flush();
        fileWriter.close();

        System.out.println("Тема " + nameOfTheme + " успешно создана!");
        return 200;
    }

    public String getServerTheme(String nameOfGlobalTheme) throws IOException //вывод всех тем
    {
        File[] listOfFiles = new File(serverThemePath + nameOfGlobalTheme + "/").listFiles();
        String result = "";
        System.out.println("path searching -> "+serverThemePath + nameOfGlobalTheme + "/");
        for (File file : listOfFiles) {
            if (file.isFile()) {
                result = result + file.getName()+"_";
            }
        }
        return result;
    }
    public String openServerTheme(String nameOfTheme, String nameOfGlobalTheme) throws IOException //выбор конкретной темы
    {
        String outputLine = "";
        BufferedReader reader = new BufferedReader(new FileReader(serverThemePath+ nameOfGlobalTheme + "/" + nameOfTheme /*+ ".txt"*/));

        while(reader.read() != -1)
        {
            outputLine += String.valueOf(reader.readLine());
        }

        return outputLine+"\n";
        //return outputLine;
    }

    public int ansverServerTheme(String nameOfTheme, String textAnsv, String nameOfGlobalTheme) throws IOException //ответ на тему
    {
        File file = new File(serverThemePath+ nameOfGlobalTheme + "/" + nameOfTheme /*+".txt"*/);

        FileWriter fileWriter = new FileWriter(file, true);

        fileWriter.write("\n________________ANSV_____________\n");
        fileWriter.write("\n"+" "+textAnsv+"\n"+" ["+currentTime.toLocalTime().toString()+"]");

        fileWriter.close();

        System.out.println("Ответ на тему " + nameOfTheme + " успешно добавлен!");
        return 200;
    }

    public String getUserName()
    {
        Random rnd = new Random();
        int userNumber = rnd.nextInt();
        String userId = "USER"+String.valueOf(userNumber);
        return userId;
    }
}

//telnet 127.0.0.1 5000
