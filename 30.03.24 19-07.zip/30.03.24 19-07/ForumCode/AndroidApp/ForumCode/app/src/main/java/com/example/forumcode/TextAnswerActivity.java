package com.example.forumcode;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;

public class TextAnswerActivity extends AppCompatActivity {
    private EditText answText;
    Intent intent;
    private String res;
    private String nameOfTheme;
    private int nameOfGlobalTheme;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.answer_content);

        intent = getIntent();
        nameOfGlobalTheme = intent.getIntExtra("nameOfGlobalTheme", 0);
        nameOfTheme = intent.getStringExtra("nameOfTheme");

        answText = findViewById(R.id.answer_id);
    }

    public void OnButtonAnswerAdd(View view) {
        Client client = new Client("ANSVF_" + nameOfTheme + "_" + answText.getText()+" ("+getUserId()+")" +"_"+nameOfGlobalTheme);
        Thread thread = new Thread(client);
        thread.start();

        synchronized (thread) {
            try {
                thread.join(); // Ожидаем завершения работы потока

                //System.out.println("qwe+"+client.response);

                res = client.response;
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        //textTitle.setText(selectedThemeListViewName);
        //textContent.setText(arraySubTheme);

        Toast.makeText(this, res, Toast.LENGTH_SHORT).show();

        finish();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Toast.makeText(this, "CLOSED!", Toast.LENGTH_SHORT).show();
        finish();
    }

    public String getUserId()
    {
        String line = "", result = "";
        try {
            FileInputStream fileInputStream = openFileInput("user_data.txt");
            InputStreamReader inputStreamReader = new InputStreamReader(fileInputStream);
            BufferedReader bufferedReader = new BufferedReader(inputStreamReader);

            while((line = bufferedReader.readLine()) != null)
            {
                result += line;
            }

            Toast.makeText(this,result, Toast.LENGTH_SHORT).show();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return result;
    }
}
